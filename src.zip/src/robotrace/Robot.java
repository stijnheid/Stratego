package robotrace;

import com.jogamp.opengl.util.gl2.GLUT;
import javax.media.opengl.GL2;
import javax.media.opengl.glu.GLU;

import static javax.media.opengl.GL.GL_FRONT_AND_BACK;
import static javax.media.opengl.fixedfunc.GLLightingFunc.*;
import static java.lang.Math.*;

/**
* Represents a Robot, to be implemented according to the Assignments.
*/
class Robot {
    
    /** The position of the robot. */
    public Vector position = new Vector(0, 0, 0);
    
    /** The direction in which the robot is running. */
    public Vector direction = new Vector(1, 0, 0);

    /** The material from which this robot is built. */
    private final Material material;

    float rightFootRotation;
    float rightKneeRotation;
    float leftFootRotation;
    float leftKneeRotation;
    float rightArmRotation;
    float leftArmRotation;
    float headRotation;


    /**
     * Constructs the robot with initial parameters.
     */
    public Robot(Material material,
                 float rf, float rk, float lf, float lk, float ra, float la, float head) {
        this.material = material;
        rightFootRotation = rf;
        rightKneeRotation = rk;
        leftFootRotation =lf;
        leftKneeRotation = lk;
        rightArmRotation = ra;
        leftArmRotation = la;
        headRotation = head;
    }

    /**
     * Draws this robot (as a {@code stickfigure} if specified).
     */
    public void draw(GL2 gl, GLU glu, GLUT glut, boolean stickFigure, float tAnim) {

        //implementation of materials

        gl.glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, this.material.diffuse, 0);   // <--does not do anything, as
        gl.glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, this.material.specular, 0); // glColorMaterials is set to
        gl.glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, this.material.shininess);   // AMBIENT_AND_DIFFUSE

        // With glColorMaterials set to only GL_AMBIENT , the difference in the colors
        // is almost unnoticeable(except for the wooden robot) and the robots look too bright
        // and artificial

        if (!stickFigure) {

            drawLeg(gl, glut, rightFootRotation, rightKneeRotation);
            gl.glPushMatrix();
            gl.glTranslatef(-0.4f, 0f, 0f);
            drawLeg(gl, glut, leftFootRotation, leftKneeRotation);
            gl.glPopMatrix();

            drawArm(gl, glut, rightArmRotation);
            gl.glPushMatrix();
            gl.glTranslatef(-0.8f, 0f, 0f);
            drawArm(gl, glut, leftArmRotation);
            gl.glPopMatrix();

            drawHead(gl, glut, headRotation);

            drawTorso(gl, glut);

        } else {

            gl.glPushMatrix();
            gl.glColor3f(0f, 0f ,0f);
            gl.glScalef(2.5f, 2.5f, 2.5f);                    //scale to the size of robots

            gl.glPushMatrix();
            gl.glScalef(0.01f, 0.07f, 0.01f);
            gl.glTranslatef(6f, 0.5f, 0f);
            glut.glutSolidCube(1f);                     //feet
            gl.glTranslatef(-12f, 0f, 0f);
            glut.glutSolidCube(1f);
            gl.glPopMatrix();

            gl.glPushMatrix();
            gl.glScalef(0.01f, 0.01f, 0.3f);
            gl.glTranslatef(6f, 0f, 0.5f);
            glut.glutSolidCube(1f);                       //legs
            gl.glTranslatef(-12f, 0f, 0f);
            glut.glutSolidCube(1f);
            gl.glPopMatrix();

            gl.glPushMatrix();
            gl.glScalef(0.12f, 0.01f, 0.01f);             //hips
            gl.glTranslatef(0f, 0f, 30f);
            glut.glutSolidCube(1f);
            gl.glPopMatrix();

            gl.glPushMatrix();
            gl.glScalef(0.01f, 0.01f, 0.37f);             //torso
            gl.glTranslatef(0f, 0f, 1.31f);
            glut.glutSolidCube(1f);
            gl.glPopMatrix();

            gl.glPushMatrix();
            gl.glScalef(0.1f, 0.01f, 0.01f);
            gl.glTranslatef(0.5f, 0f, 55f);
            glut.glutSolidCube(1f);                       //arms
            gl.glTranslatef(-1f, 0f, 0f);
            glut.glutSolidCube(1f);
            gl.glPopMatrix();

            gl.glPushMatrix();
            gl.glScalef(0.04f, 0.04f, 0.04f);
            gl.glTranslatef(0f, 0f, 16f);                 //head
            glut.glutSolidSphere(1, 10, 10);
            gl.glPopMatrix();

            gl.glPopMatrix();
        }
    }

    void drawLeg( GL2 gl, GLUT glut, float footRotation, float kneeRotation ) {

        gl.glPushMatrix();//  foot with rotations and translations
        gl.glTranslatef(0f, (float)(0.7*sin(toRadians(footRotation))), (float)(0.7-0.7*cos(toRadians(footRotation))));
        gl.glRotatef(footRotation, 1f, 0f, 0f);
        //using trigonometry these equations are found to make sure the entire object rotates around a vector parallel to the x-axis

        gl.glPushMatrix();//  knee with rotations and translations
        gl.glTranslatef(0f, (float)(0.5*sin(toRadians(kneeRotation))), (float)(0.5-0.5*cos(toRadians(kneeRotation))));
        gl.glRotatef(kneeRotation, 1f, 0f, 0f);

        gl.glPushMatrix();
        gl.glColor3d(0f, 0f, 0f);
        gl.glScalef(0.2f, 0.30f, 0.1f);
        gl.glTranslatef(1f, 1/6f, 0.5f); //foot
        glut.glutSolidCube(1f);
        gl.glPopMatrix();

        gl.glPushMatrix();
        gl.glColor3d(0f, 0f, 0f);
        gl.glScalef(0.1f, 0.10f, 0.3f);
        gl.glTranslatef(2f, 0f, 5/6f);  //lower leg
        glut.glutSolidCube(1f);
        gl.glPopMatrix();

        gl.glPopMatrix();

        gl.glPushMatrix();
        gl.glColor3d(0.1f, 0.1f, 0.1f);
        gl.glScalef(0.2f, 0.20f, 0.2f);
        gl.glTranslatef(1f, 0f, 2.5f);  // upper leg
        glut.glutSolidCube(1f);
        gl.glPopMatrix();

        gl.glPopMatrix();
    }

    void drawArm(GL2 gl, GLUT glut, float armRotation) {
        gl.glPushMatrix();
        gl.glTranslatef(0f, (float)(1.3*sin(toRadians(armRotation))), (float)(1.3-1.3*cos(toRadians(armRotation))));
        gl.glRotatef(armRotation, 1f, 0f, 0f);

        gl.glPushMatrix(); // upper arm
        gl.glColor3d(0.1f, 0.1f, 0.1f);
        gl.glScalef(0.2f, 0.20f, 0.3f);
        gl.glTranslatef(2f, 0f, 10/3*1.4f);
        glut.glutSolidCube(1f);
        gl.glPopMatrix();

        gl.glPushMatrix(); //lower arm
        gl.glColor3d(0f, 0f, 0f);
        gl.glScalef(0.1f, 0.10f, 0.2f);
        gl.glTranslatef(4f, 0f, 5*1.05f);
        glut.glutSolidCube(1f);
        gl.glPopMatrix();

        gl.glPushMatrix(); // hand
        gl.glColor3d(0.1f, 0.1f, 0.1f);
        gl.glScalef(0.18f, 0.20f, 0.2f);
        gl.glTranslatef(2.24f, 0f, 5*0.85f);
        glut.glutSolidCube(1f);
        gl.glPopMatrix();
        gl.glPopMatrix();
    }

    void drawTorso( GL2 gl, GLUT glut ) {

        gl.glPushMatrix();
        gl.glColor3d(0.6f, 0.3f, 0.2f);
        gl.glScalef(0.62f, 0.25f, 0.2f); // ass
        gl.glTranslatef(0f, 0f, 5*0.7f);
        glut.glutSolidCube(1f);
        gl.glPopMatrix();

        gl.glPushMatrix();
        gl.glColor3d(0.4f, 0.3f, 0.3f);
        gl.glScalef(0.4f, 0.22f, 0.4f); // belly
        gl.glTranslatef(0f, 0f, 10/4f);
        glut.glutSolidCube(1f);
        gl.glPopMatrix();

        gl.glPushMatrix();
        gl.glColor3d(0.6f, 0.3f, 0.2f);
        gl.glScalef(0.62f, 0.25f, 0.2f); // brest
        gl.glTranslatef(0f, 0f, 5*1.3f);
        glut.glutSolidCube(1f);
        gl.glPopMatrix();
    }
    void drawHead( GL2 gl, GLUT glut, float rotation ) {

        gl.glPushMatrix();
        gl.glRotatef(rotation, 0f, 0f, 1f);

        gl.glPushMatrix();
        gl.glColor3d(0.6f, 0.3f, 0.2f);
        gl.glTranslatef(0f, 0f, 1.4f);      // neck
        glut.glutSolidCylinder(0.1, 0.1, 20, 20);
        gl.glPopMatrix();

        gl.glPushMatrix();
        gl.glColor3d(0.4f, 0.3f, 0.2f);
        gl.glScalef(0.3f, 0.2f, 0.25f);     // head
        gl.glTranslatef(0f, 0f, 4*1.6f);
        glut.glutSolidCube(1f);
        gl.glPopMatrix();

        gl.glPushMatrix();
        gl.glColor3d(0.6f, 0.3f, 0.2f);
        gl.glTranslatef(0f, 0f, 1.7f);      // body of antenna
        glut.glutSolidCylinder(0.01, 0.1, 20, 20);
        gl.glPopMatrix();

        gl.glPushMatrix();
        gl.glColor3d(0.6f, 0.3f, 0.2f);
        gl.glTranslatef(0f, 0f, 1.8f);      // tip of antenna
        glut.glutSolidSphere(0.03, 20, 20);
        gl.glPopMatrix();

        gl.glPopMatrix();

    }
}
