package robotrace;

import javax.media.opengl.GL;

import java.awt.*;

import static javax.media.opengl.GL2.*;
import static java.lang.Math.*;

/**
 * Handles all of the RobotRace graphics functionality,
 * which should be extended per the assignment.
 * 
 * OpenGL functionality:
 * - Basic commands are called via the gl object;
 * - Utility commands are called via the glu and
 *   glut objects;
 * 
 * GlobalState:
 * The gs object contains the GlobalState as described
 * in the assignment:
 * - The camera viewpoint angles, phi and theta, are
 *   changed interactively by holding the left mouse
 *   button and dragging;
 * - The camera view width, vWidth, is changed
 *   interactively by holding the right mouse button
 *   and dragging upwards or downwards;
 * - The center point can be moved up and down by
 *   pressing the 'q' and 'z' keys, forwards and
 *   backwards with the 'w' and 's' keys, and
 *   left and right with the 'a' and 'd' keys;
 * - Other settings are changed via the menus
 *   at the top of the screen.
 * 
 * Textures:
 * Place your "track.jpg", "brick.jpg", "head.jpg",
 * and "torso.jpg" files in the same folder as this
 * file. These will then be loaded as the texture
 * objects track, bricks, head, and torso respectively.
 * Be aware, these objects are already defined and
 * cannot be used for other purposes. The texture
 * objects can be used as follows:
 * 
 * gl.glColor3f(1f, 1f, 1f);
 * track.bind(gl);
 * gl.glBegin(GL_QUADS);
 * gl.glTexCoord2d(0, 0);
 * gl.glVertex3d(0, 0, 0);
 * gl.glTexCoord2d(1, 0);
 * gl.glVertex3d(1, 0, 0);
 * gl.glTexCoord2d(1, 1);
 * gl.glVertex3d(1, 1, 0);
 * gl.glTexCoord2d(0, 1);
 * gl.glVertex3d(0, 1, 0);
 * gl.glEnd(); 
 * 
 * Note that it is hard or impossible to texture
 * objects drawn with GLUT. Either define the
 * primitives of the object yourself (as seen
 * above) or add additional textured primitives
 * to the GLUT object.
 */
public class RobotRace extends Base {
    
    /** Array of the four robots. */
    private final Robot[] robots;
    
    /** Instance of the camera. */
    private final Camera camera;
    
    /** Instance of the race track. */
    private final RaceTrack[] raceTracks;
    
    /** Instance of the terrain. */
    private final Terrain terrain;
    
    /**
     * Constructs this robot race by initializing robots,
     * camera, track, and terrain.
     */
    public RobotRace() {
        
        // Create a new array of four robots
        robots = new Robot[4];
        
        // Initialize robot 0
        robots[0] = new Robot(Material.GOLD,
                10, -10, 50, -13, 97, 180, -30);
        
        // Initialize robot 1
        robots[1] = new Robot(Material.SILVER,
                -10, -40, -5, -15, -20, 130, 0);
        
        // Initialize robot 2
        robots[2] = new Robot(Material.WOOD,
                5, -15, -10, -40, 130, -20, 0);

        // Initialize robot 3
        robots[3] = new Robot(Material.ORANGE,
                50, -13, 10, -10, 180, 97, 30);
        
        // Initialize the camera
        camera = new Camera();
        
        // Initialize the race tracks
        raceTracks = new RaceTrack[5];
        
        // Test track
        raceTracks[0] = new RaceTrack();
        
        // O-track
        raceTracks[1] = new RaceTrack(new Vector[] {
            /* add control points like:
            new Vector(10, 0, 1), new Vector(10, 5, 1), new Vector(5, 10, 1),
            new Vector(..., ..., ...), ...
            */
        });
        
        // L-track
        raceTracks[2] = new RaceTrack(new Vector[] { 
            /* add control points */
        });
        
        // C-track
        raceTracks[3] = new RaceTrack(new Vector[] { 
            /* add control points */
        });
        
        // Custom track
        raceTracks[4] = new RaceTrack(new Vector[] { 
           /* add control points */
        });
        
        // Initialize the terrain
        terrain = new Terrain();
    }
    
    /**
     * Called upon the start of the application.
     * Primarily used to configure OpenGL.
     */
    @Override
    public void initialize() {
		
        // Enable blending.
        gl.glEnable(GL_BLEND);
        gl.glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
                
        // Enable depth testing.
        gl.glEnable(GL_DEPTH_TEST);
        gl.glDepthFunc(GL_LESS);
		
	    // Normalize normals.
        gl.glEnable(GL_NORMALIZE);
        
        // Enable textures. 
        gl.glEnable(GL_TEXTURE_2D);
        gl.glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
        gl.glBindTexture(GL_TEXTURE_2D, 0);
		
	    // Try to load four textures, add more if you like.
        track = loadTexture("track.jpg");
        brick = loadTexture("brick.jpg");
        head = loadTexture("head.jpg");
        torso = loadTexture("torso.jpg");

        gs.vWidth = 720;
        gs.vDist = 150;
        gs.theta = -4.5f;
        gs.phi = 0.5f;

    }
    
    /**
     * Configures the viewing transform.
     */
    @Override
    public void setView() {
        // Select part of window.
        gl.glViewport(0, 0, gs.w, gs.h);

        // Set projection matrix.
        gl.glMatrixMode(GL_PROJECTION);
        gl.glLoadIdentity();

        // Set the perspective.
        // Modify this to meet the requirements in the assignment.
        glu.gluPerspective(2 * atan(0.5 * gs.vWidth / gs.vDist), (float) gs.w / (float) gs.h, 0.1 * gs.vDist, 10.0 * gs.vDist);
        // Set camera.
        gl.glMatrixMode(GL_MODELVIEW);
        gl.glLoadIdentity();

        // Update the view according to the camera mode and robot of interest.
        // For camera modes 1 to 4, determine which robot to focus on.
        camera.update(gs, robots[0]);
        glu.gluLookAt(camera.eye.x(), camera.eye.y(), camera.eye.z(),
                      gs.cnt.x(), gs.cnt.y(), gs.cnt.z(),
                      camera.up.x(), camera.up.y(), camera.up.z());


        //Lighting implementation

        gl.glShadeModel(GL_SMOOTH);
        gl.glEnable(GL_LIGHTING);
        gl.glEnable(GL_LIGHT0);
        gl.glEnable(GL_COLOR_MATERIAL);


        float[] whiteColor = {1.0f, 1.0f, 1.0f, 1f};
        float[] lightDir = {(float)(gs.cnt.x + gs.vDist*cos(gs.phi+toRadians(10))*cos(gs.theta+toRadians(10))), (float)(gs.cnt.y + gs.vDist*cos(gs.phi+toRadians(10))*sin(gs.theta+toRadians(10))), (float)(gs.cnt.z + gs.vDist*sin(gs.phi+toRadians(10)))};

        gl.glLightfv(GL_LIGHT0, GL_POSITION, lightDir, 0);
        gl.glLightfv(GL_LIGHT0, GL_DIFFUSE, whiteColor, 0);

    }
    /**
     * Draws the entire scene.
     */
    @Override
    public void drawScene() {
        // Background color.
        gl.glClearColor(1f, 1f, 1f, 0f);
        
        // Clear background.
        gl.glClear(GL_COLOR_BUFFER_BIT);
        
        // Clear depth buffer.
        gl.glClear(GL_DEPTH_BUFFER_BIT);
        
        // Set color to black.
        gl.glColor3f(0f, 0f, 0f);
        
        gl.glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

        // Draw robots side by side
        gl.glPushMatrix();
        gl.glTranslatef(-2.25f, 0f, 0f);
        for (Robot robot:robots) {
            robot.position = raceTracks[gs.trackNr].getLanePoint(0, 0);
            robot.direction = raceTracks[gs.trackNr].getLaneTangent(0, 0);
            robot.draw(gl, glu, glut, gs.showStick, gs.tAnim);
            gl.glTranslatef(1.5f, 0f, 0f);
        }
        gl.glPopMatrix();

        // Draw the axis frame.
        if (gs.showAxes) {
            drawAxisFrame();
        }

//          //Pink cube in viewpoint(gs.cnt))
//        gl.glPushMatrix();
//        gl.glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, new float[]{1f, 40/255f, 1f}, 0);
//        gl.glColor3f(1f, 40/255f, 1f);
//        gl.glTranslated(gs.cnt.x, gs.cnt.y, gs.cnt.z);
//        gl.glScalef(0.1f, 0.1f, 0.1f);
//        glut.glutSolidCube(1f);
//        gl.glPopMatrix();

        
        // Draw the race track.
        raceTracks[gs.trackNr].draw(gl, glu, glut);
        
        // Draw the terrain.
        terrain.draw(gl, glu, glut);
        
//        // Unit box around origin.
//        glut.glutWireCube(1f);
//
//        // Move in x-direction.
//        gl.glTranslatef(2f, 0f, 0f);
//
//        // Rotate 30 degrees, around z-axis.
//        gl.glRotatef(30f, 0f, 0f, 1f);
//
//        // Scale in z-direction.
//        gl.glScalef(1f, 1f, 2f);
//
//        // Translated, rotated, scaled box.
//        glut.glutWireCube(1f);

    }
    
    /**
     * Draws the x-axis (red), y-axis (green), z-axis (blue),
     * and origin (yellow).
     */

    public void drawAxisFrame() {

//            gl.glDisable(GL_LIGHTING);

            gl.glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, 0.05f);

            gl.glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, new float[]{1f, 1f, 0}, 0);
            gl.glColor3f(1f, 1f, 0);        //yellow sphere at the origin
            glut.glutSolidSphere(0.05, 100, 100);

            gl.glPushMatrix();
            gl.glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, new float[]{1f, 0, 0}, 0);
            gl.glColor3f(1f, 0f, 0f);
            gl.glScalef(1f, 0.01f, 0.01f);
            gl.glTranslatef(0.5f, 0f, 0f);
            glut.glutSolidCube(1f);
            gl.glPopMatrix();
                                            //x axis
            gl.glPushMatrix();
            gl.glTranslatef(1f, 0, 0);
            gl.glRotatef(90f, 0, 1f, 0);
            glut.glutSolidCone(0.04f, 0.1f, 100, 100);
            gl.glPopMatrix();

            gl.glPushMatrix();
            gl.glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, new float[]{0, 1f, 0}, 0);
            gl.glColor3f(0f, 1f, 0f);
            gl.glScalef(0.01f, 1f, 0.01f);
            gl.glTranslatef(0f, 0.5f, 0f);
            glut.glutSolidCube(1f);
            gl.glPopMatrix();
                                            //y axis
            gl.glPushMatrix();
            gl.glTranslatef(0, 1f, 0);
            gl.glRotatef(90f, -1f, 0, 0);
            glut.glutSolidCone(0.04f, 0.1f, 100, 100);
            gl.glPopMatrix();

            gl.glPushMatrix();
            gl.glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, new float[]{0, 0, 1f}, 0);
            gl.glColor3f(0f, 0f, 1f);
            gl.glScalef(0.01f, 0.01f, 1f);
            gl.glTranslatef(0f, 0f, 0.5f);
            glut.glutSolidCube(1f);
            gl.glPopMatrix();
                                            //z axis
            gl.glPushMatrix();
            gl.glTranslatef(0, 0, 1f);
            gl.glRotatef(0, 0, 0, 0);
            glut.glutSolidCone(0.04f, 0.1f, 100, 100);
            gl.glPopMatrix();
//            gl.glEnable(GL_LIGHTING);
        }


    /**
     * Main program execution body, delegates to an instance of
     * the RobotRace implementation.
     */
    public static void main(String args[]) {
        RobotRace robotRace = new RobotRace();
        robotRace.run();
    } 
}
